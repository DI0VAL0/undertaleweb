Installation:
Open DeltaPatcher and put your datawin file into the original file slot and the mod into the Xdelta patch, click apply patch and from there,
 you can put the modded datawin into Undertale. Thats it, hope you have fun!


Info:
This is a mod that swaps the sprite of Frisk with the one of Cross sans for the overworld. (Some parts aren't finished yet so your character sprite might
return to Frisk.) By the way, if you guys have any suggestions on what sprite I should mod into undertalle next, feel free to leave a suggestion
in the comments, I'll see what I can do since I barely have anything to do these days.



Update Logs:
v.1.01
-Fixed bugs

v.1.02
-improvements

v.1.03
-added toriel handhold sprite